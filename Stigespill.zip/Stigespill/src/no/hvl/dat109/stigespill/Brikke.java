package no.hvl.dat109.stigespill;

public class Brikke {
    private int posisjon = 1;

    public int getPosisjon() {
        return posisjon;
    }

    public void setPosisjon(int posisjon) {
        this.posisjon = posisjon;
    }
}
